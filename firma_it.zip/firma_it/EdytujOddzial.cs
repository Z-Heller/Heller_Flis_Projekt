﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace firma_it
{
    public partial class EdytujOddzial : Form
    {
        DatabaseHandler handler = DatabaseHandler.GetInstance();
        public static int przekazIdOddz=-1;
        public EdytujOddzial()
        {
            InitializeComponent();
            NpgsqlCommand comm = handler.ZnajdzOddzialy(przekazIdOddz);
            NpgsqlDataReader dataReader = comm.ExecuteReader(CommandBehavior.CloseConnection);
            if (dataReader.Read()) 
                MiejscEdytOddz.Text = dataReader.GetFieldValue<string>("miejscowosc");
            comm.Dispose();
            dataReader.Close();
        }

        private void ZatwEdytOddz_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(MiejscEdytOddz.Text)) MessageBox.Show("Proszę wypełnić wszystkie pola", "Błąd");
            else if (MiejscEdytOddz.Text.Any(char.IsDigit) || MiejscEdytOddz.Text.Length > 35) MessageBox.Show("Niepoprawny format", "Błąd");
            else
            {
                DatabaseHandler handler = DatabaseHandler.GetInstance();
                handler.EdytujOddzialy(przekazIdOddz, MiejscEdytOddz.Text);
                System.Windows.Forms.Application.OpenForms["Oddzial"].Refresh();
                this.Close();
            }
        }

        private void AnulujEdytOddz_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
