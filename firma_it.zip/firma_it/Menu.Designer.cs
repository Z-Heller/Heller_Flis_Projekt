﻿
namespace firma_it
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.pracownicyBttn = new System.Windows.Forms.Button();
            this.stanowiskaBttn = new System.Windows.Forms.Button();
            this.oddzialyBttn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial Black", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(196, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 28);
            this.label1.TabIndex = 2;
            this.label1.Text = "Firma IT";
            // 
            // pracownicyBttn
            // 
            this.pracownicyBttn.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.pracownicyBttn.Location = new System.Drawing.Point(168, 71);
            this.pracownicyBttn.Name = "pracownicyBttn";
            this.pracownicyBttn.Size = new System.Drawing.Size(153, 51);
            this.pracownicyBttn.TabIndex = 3;
            this.pracownicyBttn.Text = "Pracownicy";
            this.pracownicyBttn.UseVisualStyleBackColor = true;
            this.pracownicyBttn.Click += new System.EventHandler(this.pracownicyBttn_Click);
            // 
            // stanowiskaBttn
            // 
            this.stanowiskaBttn.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.stanowiskaBttn.Location = new System.Drawing.Point(168, 149);
            this.stanowiskaBttn.Name = "stanowiskaBttn";
            this.stanowiskaBttn.Size = new System.Drawing.Size(153, 51);
            this.stanowiskaBttn.TabIndex = 4;
            this.stanowiskaBttn.Text = "Stanowiska";
            this.stanowiskaBttn.UseVisualStyleBackColor = true;
            this.stanowiskaBttn.Click += new System.EventHandler(this.stanowiskaBttn_Click);
            // 
            // oddzialyBttn
            // 
            this.oddzialyBttn.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.oddzialyBttn.Location = new System.Drawing.Point(168, 229);
            this.oddzialyBttn.Name = "oddzialyBttn";
            this.oddzialyBttn.Size = new System.Drawing.Size(153, 51);
            this.oddzialyBttn.TabIndex = 5;
            this.oddzialyBttn.Text = "Oddziały";
            this.oddzialyBttn.UseVisualStyleBackColor = true;
            this.oddzialyBttn.Click += new System.EventHandler(this.oddzialyBttn_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::firma_it.Properties.Resources.tło;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(490, 312);
            this.Controls.Add(this.oddzialyBttn);
            this.Controls.Add(this.stanowiskaBttn);
            this.Controls.Add(this.pracownicyBttn);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Menu_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button pracownicyBttn;
        private System.Windows.Forms.Button stanowiskaBttn;
        private System.Windows.Forms.Button oddzialyBttn;
    }
}