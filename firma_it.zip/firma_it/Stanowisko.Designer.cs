﻿
namespace firma_it
{
    partial class Stanowisko
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabelaStanowisk = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.DodStanBtn = new System.Windows.Forms.Button();
            this.UsunStanBtn = new System.Windows.Forms.Button();
            this.EdytujStanBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tabelaStanowisk)).BeginInit();
            this.SuspendLayout();
            // 
            // tabelaStanowisk
            // 
            this.tabelaStanowisk.AllowUserToAddRows = false;
            this.tabelaStanowisk.AllowUserToDeleteRows = false;
            this.tabelaStanowisk.AllowUserToResizeRows = false;
            this.tabelaStanowisk.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tabelaStanowisk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tabelaStanowisk.Location = new System.Drawing.Point(12, 50);
            this.tabelaStanowisk.Name = "tabelaStanowisk";
            this.tabelaStanowisk.ReadOnly = true;
            this.tabelaStanowisk.RowTemplate.Height = 25;
            this.tabelaStanowisk.Size = new System.Drawing.Size(534, 173);
            this.tabelaStanowisk.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Black", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(214, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 28);
            this.label1.TabIndex = 2;
            this.label1.Text = "Stanowiska";
            // 
            // DodStanBtn
            // 
            this.DodStanBtn.Location = new System.Drawing.Point(148, 241);
            this.DodStanBtn.Name = "DodStanBtn";
            this.DodStanBtn.Size = new System.Drawing.Size(75, 23);
            this.DodStanBtn.TabIndex = 3;
            this.DodStanBtn.Text = "Dodaj";
            this.DodStanBtn.UseVisualStyleBackColor = true;
            this.DodStanBtn.Click += new System.EventHandler(this.DodStanBtn_Click);
            // 
            // UsunStanBtn
            // 
            this.UsunStanBtn.Location = new System.Drawing.Point(340, 241);
            this.UsunStanBtn.Name = "UsunStanBtn";
            this.UsunStanBtn.Size = new System.Drawing.Size(75, 23);
            this.UsunStanBtn.TabIndex = 4;
            this.UsunStanBtn.Text = "Usuń";
            this.UsunStanBtn.UseVisualStyleBackColor = true;
            this.UsunStanBtn.Click += new System.EventHandler(this.UsunStanBtn_Click);
            // 
            // EdytujStanBtn
            // 
            this.EdytujStanBtn.Location = new System.Drawing.Point(244, 241);
            this.EdytujStanBtn.Name = "EdytujStanBtn";
            this.EdytujStanBtn.Size = new System.Drawing.Size(75, 23);
            this.EdytujStanBtn.TabIndex = 5;
            this.EdytujStanBtn.Text = "Edytuj";
            this.EdytujStanBtn.UseVisualStyleBackColor = true;
            this.EdytujStanBtn.Click += new System.EventHandler(this.EdytujStanBtn_Click);
            // 
            // Stanowisko
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 286);
            this.Controls.Add(this.EdytujStanBtn);
            this.Controls.Add(this.UsunStanBtn);
            this.Controls.Add(this.DodStanBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabelaStanowisk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Stanowisko";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Stanowiska";
            ((System.ComponentModel.ISupportInitialize)(this.tabelaStanowisk)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView tabelaStanowisk;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button DodStanBtn;
        private System.Windows.Forms.Button UsunStanBtn;
        private System.Windows.Forms.Button EdytujStanBtn;
    }
}