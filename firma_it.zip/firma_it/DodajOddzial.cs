﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace firma_it
{
    public partial class DodajOddzial : Form
    {
        public DodajOddzial()
        {
            InitializeComponent();
        }

        private void AnulujOddzBtn(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ZatwOddzBtn(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(MiejscDodOddz.Text)) MessageBox.Show("Proszę wypełnić wszystkie pola", "Błąd");
            else if (MiejscDodOddz.Text.Any(char.IsDigit) || MiejscDodOddz.Text.Length > 35) MessageBox.Show("Niepoprawny format", "Błąd");
            else
            {
                DatabaseHandler handler = DatabaseHandler.GetInstance();
                handler.DodajOddzialy(MiejscDodOddz.Text);
                System.Windows.Forms.Application.OpenForms["Oddzial"].Refresh();
                this.Close();
            }
        }
    }
}
