﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace firma_it
{
    public partial class Stanowisko : Form
    {
        DatabaseHandler handler = DatabaseHandler.GetInstance();
        DataTable table = new();
        public Stanowisko()

        {
            InitializeComponent();
            Refresh();
        }

        public override void Refresh()
        {
            table.Clear();
            NpgsqlCommand comm = handler.PobierzStanowiska(); // pokaz wszystkich
            NpgsqlDataReader dataReader = comm.ExecuteReader(CommandBehavior.CloseConnection); // po dispose zamknij polaczenie z baza
            if (dataReader.HasRows)
            {
                table.Load(dataReader);
                tabelaStanowisk.DataSource = table;
            }
            comm.Dispose();
            dataReader.Close();

            handler.StanowiskoOdswiezNextVal();
        }

        private void DodStanBtn_Click(object sender, EventArgs e)
        {
            DodajStanowisko DodajStanowisko = new();
            DodajStanowisko.Show();
        }

        private void UsunStanBtn_Click(object sender, EventArgs e)
        {
            try { 
                if (tabelaStanowisk.SelectedRows.Count == 1)
                {
                    handler.UsunStanowiska(Int32.Parse(tabelaStanowisk.SelectedRows[0].Cells[0].Value.ToString()));
                    Refresh();
                }
            }
            catch (PostgresException)
            {
                MessageBox.Show("Usunięcie tego rekordu narusza klucz innej tabeli", "Błąd");
            }
        }

        private void EdytujStanBtn_Click(object sender, EventArgs e)
        {
            if (tabelaStanowisk.SelectedRows.Count == 1)
            {
                int id = Int32.Parse(tabelaStanowisk.SelectedRows[0].Cells[0].Value.ToString());
                EdytujStanowisko.przekazIdStan = id;
                EdytujStanowisko edytujStanowisko = new();
                edytujStanowisko.Show();
            }
        }
    }
}
