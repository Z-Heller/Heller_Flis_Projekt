﻿using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;


namespace firma_it
{
    public partial class Pracownik : Form
    {
        private DataTable table = new();
        private DatabaseHandler handler = DatabaseHandler.GetInstance();
        public Pracownik()
        {
            InitializeComponent();
            Refresh();
        }

        private void TrybPracownikow(object sender, EventArgs e)
        {
            if(TrybPracBtn.Text.Equals("Pokaż przełożonych")) TrybPracBtn.Text = "Pokaż podwładnych";
            else if (TrybPracBtn.Text.Equals("Pokaż podwładnych")) TrybPracBtn.Text = "Pokaż wszystkich";
            else if (TrybPracBtn.Text.Equals("Pokaż wszystkich")) TrybPracBtn.Text = "Pokaż przełożonych";
            Refresh();
        }

        public override void Refresh()
        {
            if(TrybPracBtn.Text.Equals("Pokaż przełożonych")) // teraz pokazuje wszystkich
            {
                NpgsqlCommand comm = handler.PobierzPracownikow2();
                StworzTabele(comm);
                tytul.Text = "Pracownicy - wszyscy";
            }
            else if(TrybPracBtn.Text.Equals("Pokaż podwładnych")) // teraz pokazuje przelozonych
            {
                NpgsqlCommand comm = handler.PobierzPracownikow3();
                StworzTabele(comm);
                tytul.Text = "Pracownicy - przełożeni";
            }
            else if(TrybPracBtn.Text.Equals("Pokaż wszystkich")) // teraz pokazuje podwladnych
            {
                NpgsqlCommand comm = handler.PobierzPracownikow1();
                StworzTabele(comm);
                tytul.Text = "Pracownicy - podwładni";
            }

            handler.PracownikOdswiezNextVal();
        }

        private void StworzTabele(NpgsqlCommand comm)
        {
            table.Clear();
            NpgsqlDataReader dataReader = comm.ExecuteReader(CommandBehavior.CloseConnection);
            if (dataReader.HasRows)
            {
                DataTable table = new();
                table.Load(dataReader);
                tabelaPracownikow.DataSource = table;
            }
            dataReader.Close();
            comm.Dispose();
        }

        private void DodPracBtn_Click(object sender, EventArgs e)
        {
            DodajPracownika DodajPracownika = new();
            DodajPracownika.Show();
        }

        private void EdytPracBtn_Click(object sender, EventArgs e)
        {
            if (tabelaPracownikow.SelectedRows.Count == 1)
            {
                int id = Int32.Parse(tabelaPracownikow.SelectedRows[0].Cells[0].Value.ToString());
                EdytujPracownika.przekazIdPrac = id;
                EdytujPracownika edytujPracownika = new();
                edytujPracownika.Show();
            }
        }

        private void UsunPracBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (tabelaPracownikow.SelectedRows.Count == 1)
                {
                    handler.UsunPracownikow(Int32.Parse(tabelaPracownikow.SelectedRows[0].Cells[0].Value.ToString()));
                    Refresh();
                }
            }
            catch (PostgresException)
            {
                MessageBox.Show("Usunięcie tego rekordu narusza klucz innej tabeli", "Błąd");
            }
        }

        private void search_TextChanged(object sender, EventArgs e)
        {
            if (tytul.Text == "Pracownicy - przełożeni")
            {
                (tabelaPracownikow.DataSource as DataTable).DefaultView.RowFilter =
                    string.Format("CONVERT(id_pracownika, System.String) like '{0}%' OR CONVERT(imie, System.String) like '{0}%' OR " +
                    "CONVERT(nazwisko, System.String) like '{0}%' OR CONVERT(nazwa_stanowiska, System.String) like '{0}%'" +
                    "OR CONVERT(miejscowosc, System.String) like '{0}%' OR CONVERT(data_zatrudnienia, System.String) like '{0}%'", search.Text);
            }
            else
            {
                (tabelaPracownikow.DataSource as DataTable).DefaultView.RowFilter =
                    string.Format("CONVERT(id_pracownika, System.String) like '{0}%' OR CONVERT(imie, System.String) like '{0}%' OR " +
                    "CONVERT(nazwisko, System.String) like '{0}%' OR CONVERT(nazwa_stanowiska, System.String) like '{0}%'" +
                    "OR CONVERT(miejscowosc, System.String) like '{0}%' OR CONVERT(nazwisko_przelozonego, System.String) like '{0}%' " +
                    "OR CONVERT(data_zatrudnienia, System.String) like '{0}%'", search.Text);
            }
        }
    }
}