﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace firma_it
{
    class DatabaseHandler
    {        
        private static DatabaseHandler handler;
        private String connectionString;
        public static NpgsqlConnection conn;
        private NpgsqlCommand comm = new();

        //Obiekt DatabaseHandler- zawiera informacje do polaczenia z baza
        private DatabaseHandler()
        {
            connectionString = "Server=localhost;Port=5432;Username=postgres;Password=postgres;Database=firma_IT";
        }

        //Singleton- obiekt DatabaseHandler może być tylko jeden. getInstance zwraca go, a jeśli nie istnieje- tworzy, a następnie zwraca
        public static DatabaseHandler GetInstance()
        {
            if (handler == null)
            {
                handler = new DatabaseHandler();
            }
            return handler;
        }

        //Metoda tworząca połączenie z bazą
        public void CreateConnection()
        {
            try
            {
                conn = new NpgsqlConnection(connectionString);
            }
            //Obsługa wyjątku w przypadku problemów z połączeniem
            catch (Exception)
            {
                Console.WriteLine("Nie połączono");
            }
        }
        public NpgsqlCommand PobierzPracownikow1() //podwladni
        {
            CreateConnection();
            conn.Open();

            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "SELECT a.id_pracownika,a.imie,a.nazwisko,stanowisko.nazwa_stanowiska,oddzial.miejscowosc,b.nazwisko AS nazwisko_przelozonego,a.data_zatrudnienia " +
                    "FROM((pracownik AS a " +
                    "INNER JOIN oddzial ON a.id_oddzialu = oddzial.id_oddzialu) " +
                    "INNER JOIN stanowisko ON a.id_stanowiska = stanowisko.id_stanowiska) " +
                    "INNER JOIN pracownik AS b ON a.id_przelozonego = b.id_pracownika; ";
            return comm;
        }

        public NpgsqlCommand PobierzPracownikow2() //wszyscy
        {
            CreateConnection();
            conn.Open();

            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "SELECT a.id_pracownika,a.imie,a.nazwisko,stanowisko.nazwa_stanowiska,oddzial.miejscowosc,b.nazwisko AS nazwisko_przelozonego,a.data_zatrudnienia " +
                    "FROM((pracownik AS a " +
                    "INNER JOIN oddzial ON a.id_oddzialu = oddzial.id_oddzialu) " +
                    "INNER JOIN stanowisko ON a.id_stanowiska = stanowisko.id_stanowiska) " +
                    "LEFT JOIN pracownik AS b ON a.id_przelozonego = b.id_pracownika; ";
            return comm;
        }

        public NpgsqlCommand PobierzPracownikow3() //przelozeni
        {
            CreateConnection();
            conn.Open();

            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "SELECT id_pracownika,imie,nazwisko,stanowisko.nazwa_stanowiska,oddzial.miejscowosc,data_zatrudnienia " +
                    "FROM pracownik " +
                    "INNER JOIN oddzial ON pracownik.id_oddzialu = oddzial.id_oddzialu " +
                    "INNER JOIN stanowisko ON pracownik.id_stanowiska = stanowisko.id_stanowiska " +
                    "WHERE pracownik.id_przelozonego IS NULL; ";
            return comm;
        }

        //metody odswiezajace NextVal (kolejna wartosc) dla typu SERIAL (id kolumn)
        public void PracownikOdswiezNextVal()
        {
            CreateConnection();
            conn.Open();

            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "select setval('pracownik_id_pracownika_seq', (SELECT MAX(id_pracownika) FROM pracownik));";
            comm.ExecuteNonQuery();
        }

        public void OddzialOdswiezNextVal()
        {
            CreateConnection();
            conn.Open();

            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "select setval('oddzial_id_oddzialu_seq', (SELECT MAX(id_oddzialu) FROM oddzial));";
            comm.ExecuteNonQuery();
        }

        public void StanowiskoOdswiezNextVal()
        {
            CreateConnection();
            conn.Open();

            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText = "select setval('stanowisko_id_stanowiska_seq', (SELECT MAX(id_stanowiska) FROM stanowisko));";
            comm.ExecuteNonQuery();
        }

        public void DodajPracownikow(String imie, String nazwisko, String nazwa, String miasto, String nazwiskoPrzel, DateTime data)
        {
            CreateConnection();
            conn.Open();

            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "INSERT INTO pracownik (imie,nazwisko,id_stanowiska,id_oddzialu,id_przelozonego,data_zatrudnienia) VALUES (@imie,@nazwisko," +
                    "(SELECT id_stanowiska FROM stanowisko WHERE nazwa_stanowiska = @nazwa)," +
                    "(SELECT id_oddzialu FROM oddzial WHERE miejscowosc = @miasto)," +
                    "(SELECT id_pracownika FROM pracownik WHERE nazwisko = @nazwiskoPrzel),@data);";
            comm.Parameters.AddWithValue("@imie", imie);
            comm.Parameters.AddWithValue("@nazwisko", nazwisko);
            comm.Parameters.AddWithValue("@nazwa", nazwa);
            comm.Parameters.AddWithValue("@miasto", miasto);
            comm.Parameters.AddWithValue("@nazwiskoPrzel", nazwiskoPrzel);
            comm.Parameters.AddWithValue("@data", data);
            comm.ExecuteNonQuery();
        }

        public void EdytujPracownikow(int id, String imie, String nazwisko, String nazwa, String miasto, String nazwiskoPrzel, DateTime data)
        {
            CreateConnection();
            conn.Open();
            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "UPDATE pracownik SET imie=@imie,nazwisko=@nazwisko," +
                    "id_stanowiska=(SELECT id_stanowiska FROM stanowisko WHERE nazwa_stanowiska = @nazwa)," +
                    "id_oddzialu=(SELECT id_oddzialu FROM oddzial WHERE miejscowosc = @miasto)," +
                    "id_przelozonego=(SELECT id_pracownika FROM pracownik WHERE nazwisko = @nazwiskoPrzel)," +
                    "data_zatrudnienia=@data WHERE id_pracownika=@id;";
            comm.Parameters.AddWithValue("@imie", imie);
            comm.Parameters.AddWithValue("@nazwisko", nazwisko);
            comm.Parameters.AddWithValue("@nazwa", nazwa);
            comm.Parameters.AddWithValue("@miasto", miasto);
            comm.Parameters.AddWithValue("@nazwiskoPrzel", nazwiskoPrzel);
            comm.Parameters.AddWithValue("@data", data);
            comm.Parameters.AddWithValue("@id", id);
            comm.ExecuteNonQuery();
        }

        public NpgsqlCommand ZnajdzPracownikow(int id)
        {
            CreateConnection();
            conn.Open();
            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "SELECT a.id_pracownika,a.imie,a.nazwisko,stanowisko.nazwa_stanowiska,oddzial.miejscowosc,b.nazwisko AS nazwisko_przelozonego,a.data_zatrudnienia " +
                    "FROM((pracownik AS a " +
                    "INNER JOIN oddzial ON a.id_oddzialu = oddzial.id_oddzialu) " +
                    "INNER JOIN stanowisko ON a.id_stanowiska = stanowisko.id_stanowiska) " +
                    "LEFT JOIN pracownik AS b ON a.id_przelozonego = b.id_pracownika WHERE a.id_pracownika=@id;";
            comm.Parameters.AddWithValue("@id", id);
            return comm;
        }

        public NpgsqlCommand ZnajdzStanPrac()
        {
            CreateConnection();
            conn.Open();
            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "SELECT nazwa_stanowiska FROM stanowisko;";
            return comm;
        }
        public NpgsqlCommand ZnajdzOddzPrac()
        {
            CreateConnection();
            conn.Open();
            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "SELECT miejscowosc FROM oddzial;";
            return comm;
        }
        public NpgsqlCommand ZnajdzNazwPrzel()
        {
            CreateConnection();
            conn.Open();
            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "SELECT nazwisko FROM pracownik WHERE id_przelozonego ISNULL;";
            return comm;
        }

        public void UsunPracownikow(int id)
        {
            CreateConnection();
            conn.Open();
            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "DELETE FROM pracownik WHERE id_pracownika=@id;";
            comm.Parameters.AddWithValue("@id", id);
            comm.ExecuteNonQuery();
        }

        public NpgsqlCommand PobierzOddzialy()
        {
            CreateConnection();
            conn.Open();

            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "SELECT oddzial.* , (SELECT COUNT(id_oddzialu) FROM pracownik WHERE oddzial.id_oddzialu=pracownik.id_oddzialu) AS liczba_pracowników " +
                    "FROM oddzial; ";
            return comm;
        }
        public void DodajOddzialy(String miasto)
        {
            CreateConnection();
            conn.Open();

            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "INSERT INTO oddzial (miejscowosc) VALUES (@miasto);";
            comm.Parameters.AddWithValue("@miasto", miasto);

            comm.ExecuteNonQuery();
        }

        public void EdytujOddzialy(int id, String miasto)
        {
            CreateConnection();
            conn.Open();
            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "UPDATE oddzial SET miejscowosc=@miasto WHERE id_oddzialu=@id;";
            comm.Parameters.AddWithValue("@miasto", miasto);
            comm.Parameters.AddWithValue("@id", id);
            comm.ExecuteNonQuery();
        }

        public NpgsqlCommand ZnajdzOddzialy(int id)
        {
            CreateConnection();
            conn.Open();
            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "SELECT * FROM oddzial WHERE id_oddzialu=@id;";
            comm.Parameters.AddWithValue("@id", id);
            return comm;
        }

        public void UsunOddzialy(int id)
        {
            CreateConnection();
            conn.Open();
            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "DELETE FROM oddzial WHERE id_oddzialu=@id;";
            comm.Parameters.AddWithValue("@id", id);
            comm.ExecuteNonQuery();
        }
        public NpgsqlCommand PobierzStanowiska() 
        {
            CreateConnection();
            conn.Open();

            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "SELECT stanowisko.* , (SELECT COUNT(id_stanowiska) FROM pracownik WHERE stanowisko.id_stanowiska=pracownik.id_stanowiska) AS liczba_pracowników " +
                    "FROM stanowisko; ";
            return comm;
        }
        public void DodajStanowiska(String nazwa, int pensja)
        {
            CreateConnection();
            conn.Open();
            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "INSERT INTO stanowisko (nazwa_stanowiska,pensja) VALUES (@nazwa,@pensja);";
            comm.Parameters.AddWithValue("@nazwa", nazwa);
            comm.Parameters.AddWithValue("@pensja", pensja);
            comm.ExecuteNonQuery();
        }

        public void EdytujStanowiska(int id, String nazwa, int pensja)
        {
            CreateConnection();
            conn.Open();

            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "UPDATE stanowisko SET nazwa_stanowiska=@nazwa, pensja=@pensja WHERE id_stanowiska=@id;";
            comm.Parameters.AddWithValue("@nazwa", nazwa);
            comm.Parameters.AddWithValue("@pensja", pensja);
            comm.Parameters.AddWithValue("@id", id);
            comm.ExecuteNonQuery();
        }

        public void UsunStanowiska(int id)
        {
            CreateConnection();
            conn.Open();

            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "DELETE FROM stanowisko WHERE id_stanowiska=@id;";
            comm.Parameters.AddWithValue("@id", id);
            comm.ExecuteNonQuery();
        }

        public NpgsqlCommand ZnajdzStanowiska(int id)
        {
            CreateConnection();
            conn.Open();
            comm = new NpgsqlCommand();
            comm.Connection = conn;
            comm.CommandType = CommandType.Text;
            comm.CommandText =
                    "SELECT * FROM stanowisko WHERE id_stanowiska=@id;";
            comm.Parameters.AddWithValue("@id", id);
            return comm;
        }
    }
}
