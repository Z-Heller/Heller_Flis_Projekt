﻿
namespace firma_it
{
    partial class Pracownik
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabelaPracownikow = new System.Windows.Forms.DataGridView();
            this.tytul = new System.Windows.Forms.Label();
            this.TrybPracBtn = new System.Windows.Forms.Button();
            this.DodPracBtn = new System.Windows.Forms.Button();
            this.EdytPracBtn = new System.Windows.Forms.Button();
            this.UsunPracBtn = new System.Windows.Forms.Button();
            this.search = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tabelaPracownikow)).BeginInit();
            this.SuspendLayout();
            // 
            // tabelaPracownikow
            // 
            this.tabelaPracownikow.AllowUserToAddRows = false;
            this.tabelaPracownikow.AllowUserToDeleteRows = false;
            this.tabelaPracownikow.AllowUserToResizeRows = false;
            this.tabelaPracownikow.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tabelaPracownikow.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tabelaPracownikow.Location = new System.Drawing.Point(12, 89);
            this.tabelaPracownikow.Name = "tabelaPracownikow";
            this.tabelaPracownikow.ReadOnly = true;
            this.tabelaPracownikow.RowTemplate.Height = 25;
            this.tabelaPracownikow.Size = new System.Drawing.Size(790, 445);
            this.tabelaPracownikow.TabIndex = 0;
            // 
            // tytul
            // 
            this.tytul.AutoSize = true;
            this.tytul.Font = new System.Drawing.Font("Arial Black", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tytul.Location = new System.Drawing.Point(247, 9);
            this.tytul.MinimumSize = new System.Drawing.Size(320, 0);
            this.tytul.Name = "tytul";
            this.tytul.Size = new System.Drawing.Size(320, 28);
            this.tytul.TabIndex = 1;
            this.tytul.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TrybPracBtn
            // 
            this.TrybPracBtn.Location = new System.Drawing.Point(322, 40);
            this.TrybPracBtn.Name = "TrybPracBtn";
            this.TrybPracBtn.Size = new System.Drawing.Size(170, 28);
            this.TrybPracBtn.TabIndex = 2;
            this.TrybPracBtn.Text = "Pokaż przełożonych";
            this.TrybPracBtn.UseVisualStyleBackColor = true;
            this.TrybPracBtn.Click += new System.EventHandler(this.TrybPracownikow);
            // 
            // DodPracBtn
            // 
            this.DodPracBtn.Location = new System.Drawing.Point(178, 549);
            this.DodPracBtn.Name = "DodPracBtn";
            this.DodPracBtn.Size = new System.Drawing.Size(75, 23);
            this.DodPracBtn.TabIndex = 3;
            this.DodPracBtn.Text = "Dodaj";
            this.DodPracBtn.UseVisualStyleBackColor = true;
            this.DodPracBtn.Click += new System.EventHandler(this.DodPracBtn_Click);
            // 
            // EdytPracBtn
            // 
            this.EdytPracBtn.Location = new System.Drawing.Point(365, 549);
            this.EdytPracBtn.Name = "EdytPracBtn";
            this.EdytPracBtn.Size = new System.Drawing.Size(75, 23);
            this.EdytPracBtn.TabIndex = 4;
            this.EdytPracBtn.Text = "Edytuj";
            this.EdytPracBtn.UseVisualStyleBackColor = true;
            this.EdytPracBtn.Click += new System.EventHandler(this.EdytPracBtn_Click);
            // 
            // UsunPracBtn
            // 
            this.UsunPracBtn.Location = new System.Drawing.Point(571, 549);
            this.UsunPracBtn.Name = "UsunPracBtn";
            this.UsunPracBtn.Size = new System.Drawing.Size(75, 23);
            this.UsunPracBtn.TabIndex = 5;
            this.UsunPracBtn.Text = "Usuń";
            this.UsunPracBtn.UseVisualStyleBackColor = true;
            this.UsunPracBtn.Click += new System.EventHandler(this.UsunPracBtn_Click);
            // 
            // search
            // 
            this.search.Location = new System.Drawing.Point(675, 18);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(127, 23);
            this.search.TabIndex = 6;
            this.search.TextChanged += new System.EventHandler(this.search_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(626, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "Szukaj:";
            // 
            // Pracownik
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(814, 584);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.search);
            this.Controls.Add(this.UsunPracBtn);
            this.Controls.Add(this.EdytPracBtn);
            this.Controls.Add(this.DodPracBtn);
            this.Controls.Add(this.TrybPracBtn);
            this.Controls.Add(this.tytul);
            this.Controls.Add(this.tabelaPracownikow);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Pracownik";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pracownicy";
            ((System.ComponentModel.ISupportInitialize)(this.tabelaPracownikow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView tabelaPracownikow;
        private System.Windows.Forms.Label tytul;
        private System.Windows.Forms.Button TrybPracBtn;
        private System.Windows.Forms.Button DodPracBtn;
        private System.Windows.Forms.Button EdytPracBtn;
        private System.Windows.Forms.Button UsunPracBtn;
        private System.Windows.Forms.TextBox search;
        private System.Windows.Forms.Label label1;
    }
}

