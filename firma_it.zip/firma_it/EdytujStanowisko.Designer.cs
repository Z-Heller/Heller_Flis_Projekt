﻿
namespace firma_it
{
    partial class EdytujStanowisko
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.PensjaEdytStan = new System.Windows.Forms.TextBox();
            this.AnulujEdytStan = new System.Windows.Forms.Button();
            this.ZatwEdytStan = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.NazwaEdytStan = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(135, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 15);
            this.label3.TabIndex = 18;
            this.label3.Text = "Pensja";
            // 
            // PensjaEdytStan
            // 
            this.PensjaEdytStan.Location = new System.Drawing.Point(107, 146);
            this.PensjaEdytStan.Name = "PensjaEdytStan";
            this.PensjaEdytStan.Size = new System.Drawing.Size(100, 23);
            this.PensjaEdytStan.TabIndex = 13;
            // 
            // AnulujEdytStan
            // 
            this.AnulujEdytStan.Location = new System.Drawing.Point(167, 194);
            this.AnulujEdytStan.Name = "AnulujEdytStan";
            this.AnulujEdytStan.Size = new System.Drawing.Size(75, 23);
            this.AnulujEdytStan.TabIndex = 17;
            this.AnulujEdytStan.Text = "Anuluj";
            this.AnulujEdytStan.UseVisualStyleBackColor = true;
            this.AnulujEdytStan.Click += new System.EventHandler(this.AnulujEdytStan_Click);
            // 
            // ZatwEdytStan
            // 
            this.ZatwEdytStan.Location = new System.Drawing.Point(72, 194);
            this.ZatwEdytStan.Name = "ZatwEdytStan";
            this.ZatwEdytStan.Size = new System.Drawing.Size(75, 23);
            this.ZatwEdytStan.TabIndex = 16;
            this.ZatwEdytStan.Text = "Zatwierdź";
            this.ZatwEdytStan.UseVisualStyleBackColor = true;
            this.ZatwEdytStan.Click += new System.EventHandler(this.ZatwEdytStan_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(50, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(218, 25);
            this.label2.TabIndex = 15;
            this.label2.Text = "Edytowanie stanowiska";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(107, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 15);
            this.label1.TabIndex = 14;
            this.label1.Text = "Nazwa stanowiska";
            // 
            // NazwaEdytStan
            // 
            this.NazwaEdytStan.Location = new System.Drawing.Point(110, 87);
            this.NazwaEdytStan.Name = "NazwaEdytStan";
            this.NazwaEdytStan.Size = new System.Drawing.Size(100, 23);
            this.NazwaEdytStan.TabIndex = 12;
            // 
            // EdytujStanowisko
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(316, 242);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.PensjaEdytStan);
            this.Controls.Add(this.AnulujEdytStan);
            this.Controls.Add(this.ZatwEdytStan);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NazwaEdytStan);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "EdytujStanowisko";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edytowanie stanowiska";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox PensjaEdytStan;
        private System.Windows.Forms.Button AnulujEdytStan;
        private System.Windows.Forms.Button ZatwEdytStan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox NazwaEdytStan;
    }
}