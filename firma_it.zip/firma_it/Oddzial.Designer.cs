﻿
namespace firma_it
{
    partial class Oddzial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabelaOddzialow = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.DodOddzBtn = new System.Windows.Forms.Button();
            this.UsunOddzBtn = new System.Windows.Forms.Button();
            this.EdytujOddzBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tabelaOddzialow)).BeginInit();
            this.SuspendLayout();
            // 
            // tabelaOddzialow
            // 
            this.tabelaOddzialow.AllowUserToAddRows = false;
            this.tabelaOddzialow.AllowUserToDeleteRows = false;
            this.tabelaOddzialow.AllowUserToResizeRows = false;
            this.tabelaOddzialow.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tabelaOddzialow.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tabelaOddzialow.Location = new System.Drawing.Point(12, 52);
            this.tabelaOddzialow.Name = "tabelaOddzialow";
            this.tabelaOddzialow.ReadOnly = true;
            this.tabelaOddzialow.RowTemplate.Height = 25;
            this.tabelaOddzialow.Size = new System.Drawing.Size(542, 197);
            this.tabelaOddzialow.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Black", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(235, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 28);
            this.label1.TabIndex = 3;
            this.label1.Text = "Oddziały";
            // 
            // DodOddzBtn
            // 
            this.DodOddzBtn.Location = new System.Drawing.Point(152, 273);
            this.DodOddzBtn.Name = "DodOddzBtn";
            this.DodOddzBtn.Size = new System.Drawing.Size(75, 23);
            this.DodOddzBtn.TabIndex = 4;
            this.DodOddzBtn.Text = "Dodaj";
            this.DodOddzBtn.UseVisualStyleBackColor = true;
            this.DodOddzBtn.Click += new System.EventHandler(this.DodajOddzBtn);
            // 
            // UsunOddzBtn
            // 
            this.UsunOddzBtn.Location = new System.Drawing.Point(346, 273);
            this.UsunOddzBtn.Name = "UsunOddzBtn";
            this.UsunOddzBtn.Size = new System.Drawing.Size(75, 23);
            this.UsunOddzBtn.TabIndex = 5;
            this.UsunOddzBtn.Text = "Usuń";
            this.UsunOddzBtn.UseVisualStyleBackColor = true;
            this.UsunOddzBtn.Click += new System.EventHandler(this.UsunOddzBtn_Click);
            // 
            // EdytujOddzBtn
            // 
            this.EdytujOddzBtn.Location = new System.Drawing.Point(251, 273);
            this.EdytujOddzBtn.Name = "EdytujOddzBtn";
            this.EdytujOddzBtn.Size = new System.Drawing.Size(75, 23);
            this.EdytujOddzBtn.TabIndex = 6;
            this.EdytujOddzBtn.Text = "Edytuj";
            this.EdytujOddzBtn.UseVisualStyleBackColor = true;
            this.EdytujOddzBtn.Click += new System.EventHandler(this.EdytujOddzBtn_Click);
            // 
            // Oddzial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 314);
            this.Controls.Add(this.EdytujOddzBtn);
            this.Controls.Add(this.UsunOddzBtn);
            this.Controls.Add(this.DodOddzBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabelaOddzialow);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Oddzial";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Oddziały";
            ((System.ComponentModel.ISupportInitialize)(this.tabelaOddzialow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView tabelaOddzialow;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button DodOddzBtn;
        private System.Windows.Forms.Button UsunOddzBtn;
        private System.Windows.Forms.Button EdytujOddzBtn;
    }
}