﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace firma_it
{
    public partial class DodajPracownika : Form
    {
        DatabaseHandler handler = DatabaseHandler.GetInstance();
        public DodajPracownika()
        {
            InitializeComponent();
            //zapelnij pierwszy combobox
            ZapelnijCombo(handler.ZnajdzStanPrac(),StanDodPrac,"nazwa_stanowiska");
            //drugi
            ZapelnijCombo(handler.ZnajdzOddzPrac(),OddzDodPrac,"miejscowosc");
            //trzeci
            ZapelnijCombo(handler.ZnajdzNazwPrzel(), NazwPDodPrac, "nazwisko");
            NazwPDodPrac.Items.Add(""); //przelozony?
        }

        private void ZapelnijCombo(NpgsqlCommand comm,ComboBox combo,string kolumna)
        {
            NpgsqlDataReader dataReader = comm.ExecuteReader(CommandBehavior.CloseConnection);
            while (dataReader.Read())
                combo.Items.Add(dataReader.GetFieldValue<string>(kolumna));
            combo.SelectedIndex = 0;
            comm.Dispose();
            dataReader.Close();
        }

        private void ZatwDodPrac_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ImieDodPrac.Text) || string.IsNullOrEmpty(NazwDodPrac.Text)) MessageBox.Show("Proszę wypełnić wszystkie pola", "Błąd");
            else if (ImieDodPrac.Text.Any(char.IsDigit) || NazwDodPrac.Text.Any(char.IsDigit) ||
                ImieDodPrac.Text.Length > 20 || NazwDodPrac.Text.Length > 20) MessageBox.Show("Niepoprawny format", "Błąd");
            else
            {
                handler.DodajPracownikow(ImieDodPrac.Text, NazwDodPrac.Text, StanDodPrac.Text, OddzDodPrac.Text, NazwPDodPrac.Text, DataDodPrac.Value);
                System.Windows.Forms.Application.OpenForms["Pracownik"].Refresh();
                this.Close();
            }
        }

        private void AnulujDodPrac_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
