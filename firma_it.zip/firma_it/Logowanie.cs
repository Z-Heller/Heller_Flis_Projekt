﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace firma_it
{
    public partial class Logowanie : Form
    {
        public Logowanie()
        {
            InitializeComponent();

        }

        private void Sprawdz() {
            if (LoginTbox.Text.Equals("admin") && HasloTbox.Text.Equals("admin"))
            {
                Menu menu = new();
                menu.Show();
                this.Hide();
            }
            else IncorrLbl.Visible = true;
        }


        private void ZatwLogBtn_Click(object sender, EventArgs e)
        {
            Sprawdz();
        }

        private void AnulujLogBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void HasloTbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToInt16(Keys.Enter)) Sprawdz();
        }

        private void LoginTbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToInt16(Keys.Enter)) Sprawdz();
        }
    }
}
