﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace firma_it
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void pracownicyBttn_Click(object sender, EventArgs e)
        {
            Pracownik pracOkno = new Pracownik();
            pracOkno.Show();
        }

        private void stanowiskaBttn_Click(object sender, EventArgs e)
        {
            Stanowisko stanOkno = new Stanowisko();
            stanOkno.Show();

        }

        private void oddzialyBttn_Click(object sender, EventArgs e)
        {
            Oddzial oddOkno = new Oddzial();
            oddOkno.Show();
            
        }

        private void Menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
