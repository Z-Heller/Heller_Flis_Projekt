﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace firma_it
{
    public partial class EdytujPracownika : Form
    {
        DatabaseHandler handler = DatabaseHandler.GetInstance();
        public static int przekazIdPrac = -1;
        public EdytujPracownika()
        {
            InitializeComponent();
            //zapelnij pierwszy combobox
            ZapelnijCombo(handler.ZnajdzStanPrac(), StanEdytPrac, "nazwa_stanowiska");
            //drugi
            ZapelnijCombo(handler.ZnajdzOddzPrac(), OddzEdytPrac, "miejscowosc");
            //trzeci
            ZapelnijCombo(handler.ZnajdzNazwPrzel(), NazwPEdytPrac, "nazwisko");
            NazwPEdytPrac.Items.Add(""); //przelozony?

            //przekaz parametry edytowanego do kontrolek
            NpgsqlCommand comm = handler.ZnajdzPracownikow(przekazIdPrac);
            NpgsqlDataReader dataReader = comm.ExecuteReader(CommandBehavior.CloseConnection);
            if (dataReader.Read())
            {
                ImieEdytPrac.Text = dataReader.GetFieldValue<string>("imie");
                NazwEdytPrac.Text = dataReader.GetFieldValue<string>("nazwisko");
                StanEdytPrac.Text = dataReader.GetFieldValue<string>("nazwa_stanowiska");
                OddzEdytPrac.Text = dataReader.GetFieldValue<string>("miejscowosc");
                if (!dataReader.IsDBNull("nazwisko_przelozonego")) //getfieldvalue crashuje jezeli nie odfiltruje sie nulli u przelozonych
                    NazwPEdytPrac.Text = dataReader.GetFieldValue<string>("nazwisko_przelozonego");
                DataEdytPrac.Text = dataReader.GetFieldValue<DateTime>("data_zatrudnienia").ToString();
            } 
            comm.Dispose();
            dataReader.Close();
        }

        private void ZapelnijCombo(NpgsqlCommand comm, ComboBox combo, string kolumna)
        {
            NpgsqlDataReader dataReader = comm.ExecuteReader(CommandBehavior.CloseConnection);
            while (dataReader.Read())
                combo.Items.Add(dataReader.GetFieldValue<string>(kolumna));
            comm.Dispose();
            dataReader.Close();
        }

        private void ZatwEdytPrac_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ImieEdytPrac.Text) || string.IsNullOrEmpty(NazwEdytPrac.Text)) MessageBox.Show("Proszę wypełnić wszystkie pola", "Błąd");
            else if (ImieEdytPrac.Text.Any(char.IsDigit) || NazwEdytPrac.Text.Any(char.IsDigit) ||
                ImieEdytPrac.Text.Length > 20 || NazwEdytPrac.Text.Length > 20) MessageBox.Show("Niepoprawny format", "Błąd");
            else
            {
                handler.EdytujPracownikow(przekazIdPrac, ImieEdytPrac.Text, NazwEdytPrac.Text, StanEdytPrac.Text, OddzEdytPrac.Text, NazwEdytPrac.Text, DataEdytPrac.Value);
                System.Windows.Forms.Application.OpenForms["Pracownik"].Refresh();
                this.Close();
            }
        }

        private void AnulujEdytPrac_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
