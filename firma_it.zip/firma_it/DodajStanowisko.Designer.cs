﻿
namespace firma_it
{
    partial class DodajStanowisko
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AnulujDodStan = new System.Windows.Forms.Button();
            this.ZatwDodStan = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.NazwaDodStan = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.PensjaDodStan = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // AnulujDodStan
            // 
            this.AnulujDodStan.Location = new System.Drawing.Point(164, 202);
            this.AnulujDodStan.Name = "AnulujDodStan";
            this.AnulujDodStan.Size = new System.Drawing.Size(75, 23);
            this.AnulujDodStan.TabIndex = 9;
            this.AnulujDodStan.Text = "Anuluj";
            this.AnulujDodStan.UseVisualStyleBackColor = true;
            this.AnulujDodStan.Click += new System.EventHandler(this.AnulujDodStan_Click);
            // 
            // ZatwDodStan
            // 
            this.ZatwDodStan.Location = new System.Drawing.Point(69, 202);
            this.ZatwDodStan.Name = "ZatwDodStan";
            this.ZatwDodStan.Size = new System.Drawing.Size(75, 23);
            this.ZatwDodStan.TabIndex = 8;
            this.ZatwDodStan.Text = "Zatwierdź";
            this.ZatwDodStan.UseVisualStyleBackColor = true;
            this.ZatwDodStan.Click += new System.EventHandler(this.ZatwDodStan_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(51, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(215, 25);
            this.label2.TabIndex = 7;
            this.label2.Text = "Dodawanie stanowiska";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(104, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "Nazwa stanowiska";
            // 
            // NazwaDodStan
            // 
            this.NazwaDodStan.Location = new System.Drawing.Point(104, 90);
            this.NazwaDodStan.Name = "NazwaDodStan";
            this.NazwaDodStan.Size = new System.Drawing.Size(100, 23);
            this.NazwaDodStan.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(132, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 15);
            this.label3.TabIndex = 11;
            this.label3.Text = "Pensja";
            // 
            // PensjaDodStan
            // 
            this.PensjaDodStan.Location = new System.Drawing.Point(104, 147);
            this.PensjaDodStan.Name = "PensjaDodStan";
            this.PensjaDodStan.Size = new System.Drawing.Size(100, 23);
            this.PensjaDodStan.TabIndex = 2;
            // 
            // DodajStanowisko
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(307, 251);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.PensjaDodStan);
            this.Controls.Add(this.AnulujDodStan);
            this.Controls.Add(this.ZatwDodStan);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NazwaDodStan);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "DodajStanowisko";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dodawanie stanowiska";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AnulujDodStan;
        private System.Windows.Forms.Button ZatwDodStan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox NazwaDodStan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox PensjaDodStan;
    }
}