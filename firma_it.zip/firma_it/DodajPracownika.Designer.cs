﻿
namespace firma_it
{
    partial class DodajPracownika
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.ZatwDodPrac = new System.Windows.Forms.Button();
            this.AnulujDodPrac = new System.Windows.Forms.Button();
            this.ImieDodPrac = new System.Windows.Forms.TextBox();
            this.NazwDodPrac = new System.Windows.Forms.TextBox();
            this.StanDodPrac = new System.Windows.Forms.ComboBox();
            this.OddzDodPrac = new System.Windows.Forms.ComboBox();
            this.NazwPDodPrac = new System.Windows.Forms.ComboBox();
            this.DataDodPrac = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(149, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(221, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Dodawanie pracownika";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(95, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "imię";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(95, 164);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "nazwisko";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(95, 221);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "stanowisko";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(287, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "oddział";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(287, 164);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "nazwisko przełożonego";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(287, 220);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 15);
            this.label7.TabIndex = 11;
            this.label7.Text = "data zatrudnienia";
            // 
            // ZatwDodPrac
            // 
            this.ZatwDodPrac.Location = new System.Drawing.Point(149, 295);
            this.ZatwDodPrac.Name = "ZatwDodPrac";
            this.ZatwDodPrac.Size = new System.Drawing.Size(75, 23);
            this.ZatwDodPrac.TabIndex = 12;
            this.ZatwDodPrac.Text = "Zatwierdź";
            this.ZatwDodPrac.UseVisualStyleBackColor = true;
            this.ZatwDodPrac.Click += new System.EventHandler(this.ZatwDodPrac_Click);
            // 
            // AnulujDodPrac
            // 
            this.AnulujDodPrac.Location = new System.Drawing.Point(287, 295);
            this.AnulujDodPrac.Name = "AnulujDodPrac";
            this.AnulujDodPrac.Size = new System.Drawing.Size(75, 23);
            this.AnulujDodPrac.TabIndex = 13;
            this.AnulujDodPrac.Text = "Anuluj";
            this.AnulujDodPrac.UseVisualStyleBackColor = true;
            this.AnulujDodPrac.Click += new System.EventHandler(this.AnulujDodPrac_Click);
            // 
            // ImieDodPrac
            // 
            this.ImieDodPrac.Location = new System.Drawing.Point(95, 126);
            this.ImieDodPrac.Name = "ImieDodPrac";
            this.ImieDodPrac.Size = new System.Drawing.Size(129, 23);
            this.ImieDodPrac.TabIndex = 14;
            // 
            // NazwDodPrac
            // 
            this.NazwDodPrac.Location = new System.Drawing.Point(95, 182);
            this.NazwDodPrac.Name = "NazwDodPrac";
            this.NazwDodPrac.Size = new System.Drawing.Size(129, 23);
            this.NazwDodPrac.TabIndex = 15;
            // 
            // StanDodPrac
            // 
            this.StanDodPrac.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.StanDodPrac.FormattingEnabled = true;
            this.StanDodPrac.Location = new System.Drawing.Point(95, 239);
            this.StanDodPrac.Name = "StanDodPrac";
            this.StanDodPrac.Size = new System.Drawing.Size(129, 23);
            this.StanDodPrac.TabIndex = 16;
            // 
            // OddzDodPrac
            // 
            this.OddzDodPrac.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.OddzDodPrac.FormattingEnabled = true;
            this.OddzDodPrac.Location = new System.Drawing.Point(287, 126);
            this.OddzDodPrac.Name = "OddzDodPrac";
            this.OddzDodPrac.Size = new System.Drawing.Size(129, 23);
            this.OddzDodPrac.TabIndex = 17;
            // 
            // NazwPDodPrac
            // 
            this.NazwPDodPrac.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.NazwPDodPrac.FormattingEnabled = true;
            this.NazwPDodPrac.Location = new System.Drawing.Point(287, 182);
            this.NazwPDodPrac.Name = "NazwPDodPrac";
            this.NazwPDodPrac.Size = new System.Drawing.Size(129, 23);
            this.NazwPDodPrac.TabIndex = 18;
            // 
            // DataDodPrac
            // 
            this.DataDodPrac.Location = new System.Drawing.Point(287, 238);
            this.DataDodPrac.Name = "DataDodPrac";
            this.DataDodPrac.Size = new System.Drawing.Size(129, 23);
            this.DataDodPrac.TabIndex = 19;
            this.DataDodPrac.Value = new System.DateTime(2022, 2, 9, 0, 0, 0, 0);
            // 
            // DodajPracownika
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(507, 356);
            this.Controls.Add(this.DataDodPrac);
            this.Controls.Add(this.NazwPDodPrac);
            this.Controls.Add(this.OddzDodPrac);
            this.Controls.Add(this.StanDodPrac);
            this.Controls.Add(this.NazwDodPrac);
            this.Controls.Add(this.ImieDodPrac);
            this.Controls.Add(this.AnulujDodPrac);
            this.Controls.Add(this.ZatwDodPrac);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "DodajPracownika";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dodawanie pracownika";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button ZatwDodPrac;
        private System.Windows.Forms.Button AnulujDodPrac;
        private System.Windows.Forms.TextBox ImieDodPrac;
        private System.Windows.Forms.TextBox NazwDodPrac;
        private System.Windows.Forms.ComboBox StanDodPrac;
        private System.Windows.Forms.ComboBox OddzDodPrac;
        private System.Windows.Forms.ComboBox NazwPDodPrac;
        private System.Windows.Forms.DateTimePicker DataDodPrac;
    }
}