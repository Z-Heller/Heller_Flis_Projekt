﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace firma_it
{
    public partial class Oddzial : Form
    {
        DatabaseHandler handler = DatabaseHandler.GetInstance();
        DataTable table = new();
        public Oddzial()
        {
            InitializeComponent();
            Refresh();
        }

        public override void Refresh()
        {
            table.Clear();
            NpgsqlCommand comm = handler.PobierzOddzialy(); // pokaz wszystkich
            NpgsqlDataReader dataReader = comm.ExecuteReader(CommandBehavior.CloseConnection); // po dispose zamknij polaczenie z baza
            if (dataReader.HasRows)
            {
                table.Load(dataReader);
                tabelaOddzialow.DataSource = table;
            }
            comm.Dispose();
            dataReader.Close();
            handler.OddzialOdswiezNextVal();
        }

        private void DodajOddzBtn(object sender, EventArgs e)
        {
            DodajOddzial DodajOddzial = new();
            DodajOddzial.Show();

        }

        private void UsunOddzBtn_Click(object sender, EventArgs e)
        {
            try { 
                if (tabelaOddzialow.SelectedRows.Count == 1)
                {
                    handler.UsunOddzialy(Int32.Parse(tabelaOddzialow.SelectedRows[0].Cells[0].Value.ToString()));
                    Refresh();
                }
            }
            catch (PostgresException)
            {
                MessageBox.Show("Usunięcie tego rekordu narusza klucz innej tabeli", "Błąd");
            }
        }

        private void EdytujOddzBtn_Click(object sender, EventArgs e)
        {
            if (tabelaOddzialow.SelectedRows.Count == 1)
            {
                int id = Int32.Parse(tabelaOddzialow.SelectedRows[0].Cells[0].Value.ToString());
                EdytujOddzial.przekazIdOddz = id;
                EdytujOddzial edytujOddzial = new();
                edytujOddzial.Show();
            }
        }
    }
}
