﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace firma_it
{
    public partial class EdytujStanowisko : Form
    {
        DatabaseHandler handler = DatabaseHandler.GetInstance();
        public static int przekazIdStan = -1;
        public EdytujStanowisko()
        {
            InitializeComponent();
            NpgsqlCommand comm = handler.ZnajdzStanowiska(przekazIdStan);
            NpgsqlDataReader dataReader = comm.ExecuteReader(CommandBehavior.CloseConnection);
            if (dataReader.Read()) 
            {
                NazwaEdytStan.Text = dataReader.GetFieldValue<string>("nazwa_stanowiska").ToString();
                PensjaEdytStan.Text = dataReader.GetFieldValue<int>("pensja").ToString();
            }
            comm.Dispose();
            dataReader.Close();
        }

        private void ZatwEdytStan_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(NazwaEdytStan.Text) || string.IsNullOrEmpty(PensjaEdytStan.Text)) MessageBox.Show("Proszę wypełnić wszystkie pola", "Błąd");
            else if (NazwaEdytStan.Text.Any(char.IsDigit) || PensjaEdytStan.Text.Any(char.IsLetter) ||
                NazwaEdytStan.Text.Length > 35 || PensjaEdytStan.Text.Length > 5) MessageBox.Show("Niepoprawny format", "Błąd");
            else
            {
                DatabaseHandler handler = DatabaseHandler.GetInstance();
                handler.EdytujStanowiska(przekazIdStan, NazwaEdytStan.Text, Int32.Parse(PensjaEdytStan.Text));
                System.Windows.Forms.Application.OpenForms["Stanowisko"].Refresh();
                this.Close();
            }
        }

        private void AnulujEdytStan_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
