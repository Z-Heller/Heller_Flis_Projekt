﻿
namespace firma_it
{
    partial class Logowanie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.LoginTbox = new System.Windows.Forms.TextBox();
            this.HasloTbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ZatwLogBtn = new System.Windows.Forms.Button();
            this.AnulujLogBtn = new System.Windows.Forms.Button();
            this.IncorrLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(122, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "login";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(123, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "hasło";
            // 
            // LoginTbox
            // 
            this.LoginTbox.Location = new System.Drawing.Point(123, 80);
            this.LoginTbox.Name = "LoginTbox";
            this.LoginTbox.Size = new System.Drawing.Size(100, 23);
            this.LoginTbox.TabIndex = 2;
            this.LoginTbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.LoginTbox_KeyPress);
            // 
            // HasloTbox
            // 
            this.HasloTbox.Location = new System.Drawing.Point(123, 130);
            this.HasloTbox.Name = "HasloTbox";
            this.HasloTbox.PasswordChar = '*';
            this.HasloTbox.Size = new System.Drawing.Size(100, 23);
            this.HasloTbox.TabIndex = 3;
            this.HasloTbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.HasloTbox_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(122, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "Logowanie";
            // 
            // ZatwLogBtn
            // 
            this.ZatwLogBtn.Location = new System.Drawing.Point(81, 194);
            this.ZatwLogBtn.Name = "ZatwLogBtn";
            this.ZatwLogBtn.Size = new System.Drawing.Size(75, 23);
            this.ZatwLogBtn.TabIndex = 5;
            this.ZatwLogBtn.Text = "Zatwierdź";
            this.ZatwLogBtn.UseVisualStyleBackColor = true;
            this.ZatwLogBtn.Click += new System.EventHandler(this.ZatwLogBtn_Click);
            // 
            // AnulujLogBtn
            // 
            this.AnulujLogBtn.Location = new System.Drawing.Point(194, 194);
            this.AnulujLogBtn.Name = "AnulujLogBtn";
            this.AnulujLogBtn.Size = new System.Drawing.Size(75, 23);
            this.AnulujLogBtn.TabIndex = 6;
            this.AnulujLogBtn.Text = "Anuluj";
            this.AnulujLogBtn.UseVisualStyleBackColor = true;
            this.AnulujLogBtn.Click += new System.EventHandler(this.AnulujLogBtn_Click);
            // 
            // IncorrLbl
            // 
            this.IncorrLbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.IncorrLbl.AutoSize = true;
            this.IncorrLbl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.IncorrLbl.ForeColor = System.Drawing.Color.OrangeRed;
            this.IncorrLbl.Location = new System.Drawing.Point(87, 166);
            this.IncorrLbl.Name = "IncorrLbl";
            this.IncorrLbl.Size = new System.Drawing.Size(168, 15);
            this.IncorrLbl.TabIndex = 7;
            this.IncorrLbl.Text = "Niepoprawne dane logowania!";
            this.IncorrLbl.Visible = false;
            // 
            // Logowanie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(342, 242);
            this.Controls.Add(this.IncorrLbl);
            this.Controls.Add(this.AnulujLogBtn);
            this.Controls.Add(this.ZatwLogBtn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.HasloTbox);
            this.Controls.Add(this.LoginTbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Logowanie";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Logowanie";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox LoginTbox;
        private System.Windows.Forms.TextBox HasloTbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button ZatwLogBtn;
        private System.Windows.Forms.Button AnulujLogBtn;
        private System.Windows.Forms.Label IncorrLbl;
    }
}