﻿
namespace firma_it
{
    partial class EdytujPracownika
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DataEdytPrac = new System.Windows.Forms.DateTimePicker();
            this.NazwPEdytPrac = new System.Windows.Forms.ComboBox();
            this.OddzEdytPrac = new System.Windows.Forms.ComboBox();
            this.StanEdytPrac = new System.Windows.Forms.ComboBox();
            this.NazwEdytPrac = new System.Windows.Forms.TextBox();
            this.ImieEdytPrac = new System.Windows.Forms.TextBox();
            this.AnulujEdytPrac = new System.Windows.Forms.Button();
            this.ZatwEdytPrac = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // DataEdytPrac
            // 
            this.DataEdytPrac.Location = new System.Drawing.Point(289, 233);
            this.DataEdytPrac.Name = "DataEdytPrac";
            this.DataEdytPrac.Size = new System.Drawing.Size(129, 23);
            this.DataEdytPrac.TabIndex = 34;
            this.DataEdytPrac.Value = new System.DateTime(2022, 2, 9, 0, 0, 0, 0);
            // 
            // NazwPEdytPrac
            // 
            this.NazwPEdytPrac.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.NazwPEdytPrac.FormattingEnabled = true;
            this.NazwPEdytPrac.Location = new System.Drawing.Point(289, 175);
            this.NazwPEdytPrac.Name = "NazwPEdytPrac";
            this.NazwPEdytPrac.Size = new System.Drawing.Size(129, 23);
            this.NazwPEdytPrac.TabIndex = 33;
            // 
            // OddzEdytPrac
            // 
            this.OddzEdytPrac.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.OddzEdytPrac.FormattingEnabled = true;
            this.OddzEdytPrac.Location = new System.Drawing.Point(289, 111);
            this.OddzEdytPrac.Name = "OddzEdytPrac";
            this.OddzEdytPrac.Size = new System.Drawing.Size(129, 23);
            this.OddzEdytPrac.TabIndex = 32;
            // 
            // StanEdytPrac
            // 
            this.StanEdytPrac.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.StanEdytPrac.FormattingEnabled = true;
            this.StanEdytPrac.Location = new System.Drawing.Point(79, 234);
            this.StanEdytPrac.Name = "StanEdytPrac";
            this.StanEdytPrac.Size = new System.Drawing.Size(129, 23);
            this.StanEdytPrac.TabIndex = 31;
            // 
            // NazwEdytPrac
            // 
            this.NazwEdytPrac.Location = new System.Drawing.Point(79, 175);
            this.NazwEdytPrac.Name = "NazwEdytPrac";
            this.NazwEdytPrac.Size = new System.Drawing.Size(129, 23);
            this.NazwEdytPrac.TabIndex = 30;
            // 
            // ImieEdytPrac
            // 
            this.ImieEdytPrac.Location = new System.Drawing.Point(79, 111);
            this.ImieEdytPrac.Name = "ImieEdytPrac";
            this.ImieEdytPrac.Size = new System.Drawing.Size(129, 23);
            this.ImieEdytPrac.TabIndex = 29;
            // 
            // AnulujEdytPrac
            // 
            this.AnulujEdytPrac.Location = new System.Drawing.Point(289, 294);
            this.AnulujEdytPrac.Name = "AnulujEdytPrac";
            this.AnulujEdytPrac.Size = new System.Drawing.Size(75, 23);
            this.AnulujEdytPrac.TabIndex = 28;
            this.AnulujEdytPrac.Text = "Anuluj";
            this.AnulujEdytPrac.UseVisualStyleBackColor = true;
            this.AnulujEdytPrac.Click += new System.EventHandler(this.AnulujEdytPrac_Click);
            // 
            // ZatwEdytPrac
            // 
            this.ZatwEdytPrac.Location = new System.Drawing.Point(144, 294);
            this.ZatwEdytPrac.Name = "ZatwEdytPrac";
            this.ZatwEdytPrac.Size = new System.Drawing.Size(75, 23);
            this.ZatwEdytPrac.TabIndex = 27;
            this.ZatwEdytPrac.Text = "Zatwierdź";
            this.ZatwEdytPrac.UseVisualStyleBackColor = true;
            this.ZatwEdytPrac.Click += new System.EventHandler(this.ZatwEdytPrac_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(289, 215);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 15);
            this.label7.TabIndex = 26;
            this.label7.Text = "data zatrudnienia";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(289, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 15);
            this.label6.TabIndex = 25;
            this.label6.Text = "nazwisko przełożonego";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(289, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 15);
            this.label5.TabIndex = 24;
            this.label5.Text = "oddział";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(79, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 15);
            this.label4.TabIndex = 23;
            this.label4.Text = "stanowisko";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(79, 157);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 15);
            this.label2.TabIndex = 22;
            this.label2.Text = "nazwisko";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(79, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 15);
            this.label1.TabIndex = 21;
            this.label1.Text = "imię";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(144, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(224, 25);
            this.label3.TabIndex = 20;
            this.label3.Text = "Edytowanie pracownika";
            // 
            // EdytujPracownika
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(507, 352);
            this.Controls.Add(this.DataEdytPrac);
            this.Controls.Add(this.NazwPEdytPrac);
            this.Controls.Add(this.OddzEdytPrac);
            this.Controls.Add(this.StanEdytPrac);
            this.Controls.Add(this.NazwEdytPrac);
            this.Controls.Add(this.ImieEdytPrac);
            this.Controls.Add(this.AnulujEdytPrac);
            this.Controls.Add(this.ZatwEdytPrac);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "EdytujPracownika";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edytowanie pracownika";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker DataEdytPrac;
        private System.Windows.Forms.ComboBox NazwPEdytPrac;
        private System.Windows.Forms.ComboBox OddzEdytPrac;
        private System.Windows.Forms.ComboBox StanEdytPrac;
        private System.Windows.Forms.TextBox NazwEdytPrac;
        private System.Windows.Forms.TextBox ImieEdytPrac;
        private System.Windows.Forms.Button AnulujEdytPrac;
        private System.Windows.Forms.Button ZatwEdytPrac;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
    }
}