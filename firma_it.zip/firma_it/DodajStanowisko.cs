﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace firma_it
{
    public partial class DodajStanowisko : Form
    {
        public DodajStanowisko()
        {
            InitializeComponent();
        }

        private void ZatwDodStan_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(NazwaDodStan.Text) || string.IsNullOrEmpty(PensjaDodStan.Text)) MessageBox.Show("Proszę wypełnić wszystkie pola", "Błąd");
            else if (NazwaDodStan.Text.Any(char.IsDigit) || PensjaDodStan.Text.Any(char.IsLetter) ||
                NazwaDodStan.Text.Length > 35 || PensjaDodStan.Text.Length > 5) MessageBox.Show("Niepoprawny format", "Błąd");
            else
            {
                DatabaseHandler handler = DatabaseHandler.GetInstance();
                handler.DodajStanowiska(NazwaDodStan.Text, Int32.Parse(PensjaDodStan.Text));
                System.Windows.Forms.Application.OpenForms["Stanowisko"].Refresh();
                this.Close();
            }
        }

        private void AnulujDodStan_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
